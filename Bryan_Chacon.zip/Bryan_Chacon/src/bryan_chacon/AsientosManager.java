
package bryan_chacon;
import javax.swing.JOptionPane;

public class AsientosManager {
    private char[][] asientos;
    private int filas;
    private int columnas;

    public AsientosManager(int filas, int columnas) {
        this.filas = filas;
        this.columnas = columnas;
        this.asientos = new char[filas][columnas];
    }

    public void inicializarAsientos() {
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                asientos[i][j] = '-';
            }
        }
    }

    public void mostrarAsientos(String pelicula) {
        StringBuilder asientosStr = new StringBuilder();
        asientosStr.append("  ");

        for (int j = 0; j < columnas; j++) {
            asientosStr.append(j + 1).append(" ");
        }
        asientosStr.append("\n");

        for (int i = 0; i < filas; i++) {
            asientosStr.append((char) ('A' + i)).append(" ");
            for (int j = 0; j < columnas; j++) {
                asientosStr.append(asientos[i][j]).append(" ");
            }
            asientosStr.append("\n");
        }

        JOptionPane.showMessageDialog(null, "Asientos disponibles:\n" + asientosStr + "\nPelícula: " + pelicula);
    }

    public void asignarAsiento() {
        String filaStr = JOptionPane.showInputDialog("Ingrese la fila (A-" + (char) ('A' + filas - 1) + "):");
        String columnaStr = JOptionPane.showInputDialog("Ingrese la columna (1-" + columnas + "):");

        if (filaStr != null && columnaStr != null && !filaStr.isEmpty() && !columnaStr.isEmpty()) {
            int fila = filaStr.toUpperCase().charAt(0) - 'A';
            int columna = Integer.parseInt(columnaStr) - 1;

            if (fila >= 0 && fila < filas && columna >= 0 && columna < columnas) {
                if (asientos[fila][columna] == '-') {
                    asientos[fila][columna] = 'X';
                    JOptionPane.showMessageDialog(null, "Asiento " + filaStr + (columna + 1) + " asignado correctamente.");
                } else {
                    JOptionPane.showMessageDialog(null, "El asiento " + filaStr + (columna + 1) + " ya está ocupado.");
                }
            } else {
                JOptionPane.showMessageDialog(null, "Fila o columna inválida.");
            }
        }
    }
}

