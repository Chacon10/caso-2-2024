package bryan_chacon;
import javax.swing.JOptionPane;
public class Bryan_Chacon {

    public static void main(String[] args) {
    
   CineOficina cine = new CineOficina();
    cine.iniciarCine();
    }
}


