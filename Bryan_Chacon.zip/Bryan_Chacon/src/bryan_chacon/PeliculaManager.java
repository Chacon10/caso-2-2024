package bryan_chacon;

import javax.swing.JOptionPane;

public class PeliculaManager {

    private String pelicula;

    public void inicializarPelicula() {
        pelicula = "Película del día";
    }

    public String getPelicula() {
        return pelicula;
    }

    public void modificarPelicula() {
        String nuevaPelicula = JOptionPane.showInputDialog("Ingrese el nombre de la nueva película:");
        if (nuevaPelicula != null && !nuevaPelicula.isEmpty()) {
            pelicula = nuevaPelicula;
            JOptionPane.showMessageDialog(null, "La película ha sido cambiada a: " + pelicula);
        }
    }
}
