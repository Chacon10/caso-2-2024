package bryan_chacon;
import javax.swing.JOptionPane;
public class CineOficina {

    private static final int FILAS = 6;
    private static final int COLUMNAS = 8;
    private AsientosManager asientosManager;
    private PeliculaManager peliculaManager;

    public CineOficina() {
        asientosManager = new AsientosManager(FILAS, COLUMNAS);
        peliculaManager = new PeliculaManager();
    }

    public void iniciarCine() {
        asientosManager.inicializarAsientos();
        peliculaManager.inicializarPelicula();
        mostrarMenu();
    }

    private void mostrarMenu() {
        int opcion;
        do {
            opcion = mostrarMenuOpciones();
            ejecutarOpcion(opcion);
        } while (opcion != 4);
    }

    private int mostrarMenuOpciones() {
        String menu = "Seleccione una opción:\n"
                + "1. Mostrar asientos y película\n"
                + "2. Modificar película\n"
                + "3. Asignar asiento\n"
                + "4. Salir";
        return Integer.parseInt(JOptionPane.showInputDialog(menu));
    }

    private void ejecutarOpcion(int opcion) {
        switch (opcion) {
            case 1:
                asientosManager.mostrarAsientos(peliculaManager.getPelicula());
                break;
            case 2:
                peliculaManager.modificarPelicula();
                break;
            case 3:
                asientosManager.asignarAsiento();
                break;
            case 4:
                JOptionPane.showMessageDialog(null, "¡Hasta luego!");
                break;
            default:
                JOptionPane.showMessageDialog(null, "Opción inválida");
        }
    }

}
